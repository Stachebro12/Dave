using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{
    public KeyCode upKey;
    public KeyCode downKey;
    public KeyCode leftKey;
    public KeyCode rightKey;
    public float sprintSpeed;
    private float modifier = 0f;
    public float distX;
    public float distY;
    public float distD;

    private Rigidbody2D rigidBody;

    // Start is called before the first frame update
    void Start()
    {
        rigidBody = GetComponent<Rigidbody2D> ();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(downKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(0, -distY - modifier, 0));
            transform.localRotation = Quaternion.Euler(0, 0, 180);
        }
        if (Input.GetKey(upKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(0, distY + modifier, 0));
            transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
        if (Input.GetKey(rightKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(distX + modifier, 0, 0));
            transform.localRotation = Quaternion.Euler(0, 0, 270);
        }
        if (Input.GetKey(leftKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(-distX - modifier, 0, 0));
            transform.localRotation = Quaternion.Euler(0, 0, 90);
        }
        if (Input.GetKey(upKey) && Input.GetKey(rightKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(distD + modifier, distD + modifier, 0));
        }
        if (Input.GetKey(upKey) && Input.GetKey(leftKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(-distD - modifier, distD + modifier, 0));
        }
        if (Input.GetKey(downKey) && Input.GetKey(rightKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(distD + modifier, -distD - modifier, 0));
        }
        if (Input.GetKey(downKey) && Input.GetKey(leftKey))
        {
            rigidBody.MovePosition(transform.position + new Vector3(-distD - modifier, -distD - modifier, 0));
        }
        
        if (Input.GetButtonDown("Sprint"))
        {
            modifier = sprintSpeed;
        }
        if (Input.GetButtonUp("Sprint"))
        {
            modifier = 0f;
        }
    }
}
